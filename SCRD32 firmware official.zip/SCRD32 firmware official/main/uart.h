#ifndef UART_H
#define UART_H

#define ADDRESS_CHANNEL 0x000000
void readChannelInfo();
void saveChannelInfo();
void createUartTasks(void);
#endif